import React from 'react'

const Navbar = () => {
    return (
        <nav>
            <p>Stuff</p>
        </nav>
    )
}

export default Navbar
