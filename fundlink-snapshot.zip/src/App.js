import React from 'react';
// React Router
import { BrowserRouter as Router } from 'react-router-dom';
// Style
import './App.css';
// Components
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';

function App() {
  return (
    <Router>
      <div className="App">
          <Sidebar />
          <main>
            <Navbar />
          </main>
          <aside></aside>
      </div>
    </Router>
  );
}

export default App;

// Design Inspiration
// https://dribbble.com/shots/14671619/attachments/6368071?mode=media